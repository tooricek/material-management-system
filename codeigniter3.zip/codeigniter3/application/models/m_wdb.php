<?php

class M_wdb extends CI_Model {
public function get_data(){
    return $this->db->get("material_items")->result_array();
}

}