<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Prodepart extends CI_Controller {
	public function index() {
		//Load Model
		$this->load->model('m_wdb');
		$data['material_items']= $this->m_wdb->get_data();

		//Load View
		$this->load->view('matitem',$data);
	}
	public function get_action(){
		$material_name = $this->input->post("material_name");
		$requested_quantity = $this->input->post("requested_quantity");
		$usage_description = $this->input->post("usage_description");
		
		$data = array( 
			'material_name' => $material_name,
			'requested_quantity'=> $requested_quantity,
			'usage_description'=> $usage_description,
		);

		$this->load->model('m_wdb');
		$this->m_wdb->input_data($data, 'material_items');
		header('prodepart/index');
		}
}
