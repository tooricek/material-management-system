<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Material Items Data</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">



    <!-- Bootstrap JS and Popper.js (required for Bootstrap) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
</head>

<body>


<div class = "content-wrapper">
    <section class = "content-header">
        <h1>
            Materials
        </h1>
        </section>

    <section class = "content">
        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Add Material Data</button>
        <table class ="table", border ="1px solid black">
            <tr>
                <th>NO</th>
                <th>REQ ID</th>
                <th>MATERIAL NAME</th>
                <th>REQ QUANTITY</th>
                <th>USAGE</th>
            </tr>
            <?php 
            $no = 1;
            foreach ($material_items as $item): ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $item['request_id'] ?></td>
                <td><?php echo $item['material_name'] ?></td>
                <td><?php echo $item['requested_quantity'] ?></td>
                <td><?php echo $item['usage_description'] ?></td>
            </tr>    
            
            <?php endforeach; ?>
        </table>

    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Input Item Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method= "post" action="<?php echo base_url().'Prodepart/get_action'; ?>">
            <div class="form-group">
                <label>Material Name</label>
                <input type="text" name = "material_name" class = "form-control">
            </div>
            <div class="form-group">
                <label>Requested Quantity</label>
                <input type="text" name = "requested_quantity" class = "form-control">
            </div>
            <div class="form-group">
                <label>Usage Description</label>
                <input type="text" name = "usage_description" class = "form-control">
            </div>

            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
        
      </div>
    </div>
  </div>
</div>
</body>
</html>