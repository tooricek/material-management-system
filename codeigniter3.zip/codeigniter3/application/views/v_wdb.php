<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Material Request's Items</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <table border="1px solid black">
        <tr>
            <th>Username</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Department</th>
        </tr>
        <?php foreach ($users as $us): ?>
        <tr>
            <td><?php echo $us ['username'];?></td>
            <td><?php echo $us ['full_name'];?></td>
            <td><?php echo $us ['email'];?></td>
            <td><?php echo $us ['department_id'];?></td>
        </tr>
        <?php endforeach; ?>
</body>
</html>